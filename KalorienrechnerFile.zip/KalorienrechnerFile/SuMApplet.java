import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class SuMApplet extends Applet
{
    public SuMApplet()
    {
        SuMAnwendung hatSuMAnwendung = new SuMAnwendung();
        hatSuMAnwendung.fuehreAus();
    }

}
