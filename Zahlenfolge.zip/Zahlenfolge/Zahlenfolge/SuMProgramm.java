public class SuMProgramm
{
    public static void main(String args[])
    {
        SuMAnwendung hatSuMAnwendung = new SuMAnwendung();
        hatSuMAnwendung.fuehreAus();
    }

}
